require('common');

local settings = T{ };
settings["font"] = T{ };
settings["fps"] = T{ };
settings["font"]["font_height"] = 12;
settings["font"]["font_family"] = "Arial";
settings["font"]["color"] = 4294901760;
settings["font"]["visible"] = true;
settings["font"]["position_y"] = 1;
settings["font"]["position_x"] = 1;
settings["fps"]["format"] = "%d";

return settings;
