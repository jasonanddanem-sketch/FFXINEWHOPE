require('common');

local settings = T{ };
settings["font"] = T{ };
settings["font"]["font_height"] = 16;
settings["font"]["font_family"] = "Arial";
settings["font"]["bold"] = true;
settings["font"]["color"] = 4294967295;
settings["font"]["visible"] = true;
settings["font"]["position_y"] = 20;
settings["font"]["position_x"] = -180;

return settings;
