require('common');

local settings = T{ };
settings["format"] = "\30Q[%H:%M:%S]\30\1";

return settings;
